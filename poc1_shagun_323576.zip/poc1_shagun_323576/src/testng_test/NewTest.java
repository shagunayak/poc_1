package testng_test;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.poi.util.SystemOutLogger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import aut_features.Create_account;
import base_class.Person;
import excel_io.Excel_operation;

public class NewTest extends Create_account {
	
	String act_res,exp_res;
	String [] exp_results;
	Excel_operation eo=new Excel_operation();
	String test_result;
	int i=0;
	int j=0;
	 Logger log=Logger.getLogger("devpinoyLogger");
	 
	
@BeforeClass
	public void beforeclass() {
	log.info("all data initialization started");
	exp_results=get_data();
	log.info("all data initilaiztion done successfully");
	}
	
	
	@Test(dataProvider = "logintest")
  public void f(String exp_res) {
	   
		
		j=i+1;
		log.info("TCD_ID"+j);
		log.info("Started resister method for "+ j+"th data in list");
	    act_res=  register(i);
	    exp_res=exp_results[i];
	    log.info("Expected value for "+ j+"th data is: "+ exp_res);
	    log.info("Actual value for "+ j+"th data is: "+ act_res);
	
	  System.out.println(act_res);
	  if(act_res.compareTo(exp_res)==0) {
		   test_result="Pass";
	  }
	  else
		  test_result="Fail";
	  log.info("Test case Result for "+ i+"th data is: "+ test_result);
	  eo.write_excel(i, act_res, test_result);
	  log.info("Test Result updated in Excel Sheet ");
	  Assert.assertEquals(act_res, exp_results[i]);
	  
	  i++;
	  
  }
  
	 @DataProvider
	 public String[] logintest()
	  {

	    return exp_results;
	    
	  }
	  
  
  
  
  
  
  
  
  
  
  
}
