package aut_features;

import java.util.ArrayList;
import java.util.LinkedList;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.List;
import base_class.Launch_browser;
import base_class.Person;
import excel_io.Excel_operation;

public class Create_account{
	

	Launch_browser lb=new Launch_browser();
	WebDriver dr;
    String tcd_id,firstname,lastname,email,passowrd,address,city,state,country,aliasaddress,exp_res,act_res,test_result;
	
	int zipcode;
	int mobileno;
	
	String mob,post;

	static Excel_operation e;
	 static ArrayList<Person> al;
	 String exp_result[];
	 
	public String[] get_data() {
		
		e=new Excel_operation();
		al=e.read_excel();
		exp_result=exp_result();
		return exp_result ;
	}
	
	 
	 
public String register(int i)
	{
		
	
		  tcd_id=al.get(i).getTcd_id();
		  firstname=al.get(i).getFirstname();
		  lastname=al.get(i).getLastname();
		  email=al.get(i).getEmail();
		  passowrd=al.get(i).getPassowrd();
		  address=al.get(i).getAddress();
		  city=al.get(i).getCity();
		  state=al.get(i).getState();
		  country=al.get(i).getCountry();
		  aliasaddress=al.get(i).getAliasaddress();
		  zipcode=al.get(i).getZipcode();
		  mobileno=al.get(i).getMobileno();
		  mob=Integer.toString(mobileno);
		  post=Integer.toString(zipcode);
		  
		  
		  dr=lb.launch("http://automationpractice.com/index.php", "chrome");
		  dr.findElement(By.className("login")).click();
		  dr.findElement(By.id("email_create")).sendKeys(email);
		  dr.findElement(By.name("SubmitCreate")).click();
		  
		  WebDriverWait wait = new WebDriverWait(dr,10);
		  wait.until(ExpectedConditions.elementToBeClickable(By.id("id_gender1")));
		  
		  dr.findElement(By.xpath("//*[@id='customer_firstname']")).sendKeys(firstname);
		  dr.findElement(By.xpath("//*[@id='customer_lastname']")).sendKeys(lastname);
		  dr.findElement(By.xpath("//*[@id='passwd']")).sendKeys(passowrd);
		  
		  
		    WebElement wel3=dr.findElement(By.id("id_state"));
			WebElement wel4=dr.findElement(By.id("id_country"));
			Select sel3=new Select(wel3);
			Select sel4=new Select(wel4);
			sel3.selectByVisibleText(state);
			sel4.selectByVisibleText(country);
		  
		  dr.findElement(By.name("address1")).sendKeys(address);
		  dr.findElement(By.name("city")).sendKeys(city);
		  dr.findElement(By.name("postcode")).sendKeys(post);
		  dr.findElement(By.name("phone_mobile")).sendKeys(mob);
		  dr.findElement(By.name("alias")).sendKeys(aliasaddress);
		  dr.findElement(By.name("submitAccount")).click();
		  wait.until(ExpectedConditions.titleContains("My account"));
		  act_res=dr.findElement(By.className("account")).getText();
		  dr.findElement(By.className("logout")).click();
			dr.close();
		return act_res;
		
	}
	
	
	public String[] exp_result() {
		
		
		List<String>  list=new LinkedList<String>();
		
          for(Person p: al) 
          {
			list.add(p.getExp_res());
		  }
          
          String[] arr = new String[list.size()]; 
          for (int i =0; i < list.size(); i++) 
              arr[i] = list.get(i);
		return arr;
		
	}
	
	
		
		
		
	
	
	
	
}
