package test;

public class Birdsan {
	
	static String type_of_bird;

	public Birdsan(String type_of_bird) {
		
		this.type_of_bird = type_of_bird;
	}

	public String getType_of_bird() {
		return type_of_bird;
	}

	public void setType_of_bird(String type_of_bird) {
		this.type_of_bird = type_of_bird;
	}
	

}
