package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Arraylist {

	
	public Product read_excel(int i)
	{
		int product_id = 0,rate = 0,no_pur = 0;
		String name = null;
		try {
			File f=new File("test.xlsx");
			FileInputStream fin=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fin);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow row=sh.getRow(i);
			XSSFCell cell=row.getCell(0);
			product_id=(int) cell.getNumericCellValue();
			XSSFCell cell1=row.getCell(1);
			 name=cell1.getStringCellValue();
			XSSFCell cell2=row.getCell(2);
			rate =(int) cell2.getNumericCellValue();
			XSSFCell cell3=row.getCell(3);
			 no_pur=(int) cell3.getNumericCellValue();
			// System.out.println(rate);			 
		//	 System.out.println(no_pur);	
		int price=rate*no_pur;
		FileOutputStream fio=new FileOutputStream(f);
		XSSFCell cell4=row.createCell(4);
		cell4.setCellValue(price);
		String grade;
		
		if(price>=25000)
			grade="b";
		else
			grade="a";
		
		XSSFCell cell5=row.createCell(5);
		cell5.setCellValue(grade);
		
		wb.write(fio);
		
		
			
			
		} catch ( IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Product p=new Product(product_id, name, rate, no_pur);
		return p;
	}
	
	
	public void write_excel(int i)
	{
		
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
              Arraylist al=new Arraylist();
              ArrayList<Product> a=new ArrayList<Product>();
              Product p;
              
              for(int i=1;i<=3;i++)
              {
            	  		p=al.read_excel(i);
            	  		a.add(p);
            	  		
            	  		
            	  		
              }
		
	}

}
