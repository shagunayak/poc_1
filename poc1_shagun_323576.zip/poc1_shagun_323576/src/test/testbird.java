package test;

public class testbird {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Parrot r=new Parrot("PARROT", 1, "parrot", "south america", "human");
		Parrot r1=new Parrot("PARROT", 2, "parrot1", "central america", "human2");
		Parrot r2=new Parrot("PARROT", 3, "parrot2", "austrila", "human3");
		
		
		Owl o=new Owl("owl", 1, "owl1", "india", 10);
		Owl o1=new Owl("owl", 1, "owl2", "india west", 5);
		
		
		
		
	System.out.print("Type="+r.type_of_bird+" id="+r.id+" name="+r.name+" origin"+r.origin+" sound="+r.sound);
	System.out.print("Type="+r2.type_of_bird+" id="+r2.id+" name="+r2.name+" origin"+r2.origin+" sound="+r2.sound);
	System.out.print("Type="+r1.type_of_bird+" id="+r1.id+" name="+r1.name+" origin"+r1.origin+" sound="+r1.sound);
	
	
	
		
		
		
	}

}
