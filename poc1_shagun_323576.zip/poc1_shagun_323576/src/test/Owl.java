package test;

public class Owl extends Birdsan {
	
	int id;
	String name;
	String place;
	int sight_range;
	public Owl(String type_of_bird,int id, String name, String place, int sight_range) {
		super(type_of_bird);
		this.id = id;
		this.name = name;
		this.place = place;
		this.sight_range = sight_range;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public int getSight_range() {
		return sight_range;
	}
	public void setSight_range(int sight_range) {
		this.sight_range = sight_range;
	}
	
	

}
