package test;

public class Product {
	
	int product_id;
	String product_name;
	int  rate;
	int no_pur;
	
	public Product(int product_id, String product_name, int rate, int no_pur) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.rate = rate;
		this.no_pur = no_pur;
	}

	@Override
	public String toString() {
		return "Product [product_id=" + product_id + ", product_name=" + product_name + ", rate=" + rate + ", no_pur="
				+ no_pur + "]";
	}
	
	

}
