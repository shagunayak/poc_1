package test;

public class Stringvowel {

	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         String line = "I have learnt loops opps concepts inheritance exception handling arraylist and string handling ";
         
         int s=line.length();
         int n = 0;
         int start_index=0,null_index;
         for(int i=0;i<=s;i++)
         {

    		 null_index=line.indexOf(" ", start_index);
    		 if(null_index==s)
    			 break;
    		 String str=line.substring(start_index, null_index);
    		 start_index=null_index+1;
    		 
    		// System.out.println(str);
    	      String 	 str1=str.toLowerCase();
    	      System.out.println(str1);
        	       int c=0;
    		 for(int j=0;j<=str1.length()-1;j++)
    		 {
    			 char st=str1.charAt(j);
    			
    			 if(st==('a'|'e'|'i'|'o'|'u')) {
    				 c++;
    			 }
    				 
    		 }
    		 if(c>3)
    		 {
    			 System.out.println(str);
    		 }
    		// System.out.println(null_index);
    		 //System.out.println(start_index);
    		
    		 
         }
        	 
        		
        		 
        		 
        	 
         }
		
	}


