package base_class;

public class Person
{

	String tcd_id,firstname,lastname,email,passowrd,address,city,state,country,aliasaddress,exp_res,act_res,test_result;
	
	int zipcode,mobileno;

	public Person(String tcd_id, String firstname, String lastname, String email, String passowrd, String address,
			String city, String state, String country, String aliasaddress, String exp_res, int zipcode, int mobileno) {
		super();
		this.tcd_id = tcd_id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.passowrd = passowrd;
		this.address = address;
		this.city = city;
		this.state = state;
		this.country = country;
		this.aliasaddress = aliasaddress;
		this.exp_res = exp_res;
		this.zipcode = zipcode;
		this.mobileno = mobileno;
	}

	public String getTcd_id() {
		return tcd_id;
	}

	public void setTcd_id(String tcd_id) {
		this.tcd_id = tcd_id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassowrd() {
		return passowrd;
	}

	public void setPassowrd(String passowrd) {
		this.passowrd = passowrd;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getAliasaddress() {
		return aliasaddress;
	}

	public void setAliasaddress(String aliasaddress) {
		this.aliasaddress = aliasaddress;
	}

	public String getExp_res() {
		return exp_res;
	}

	public void setExp_res(String exp_res) {
		this.exp_res = exp_res;
	}

	public String getAct_res() {
		return act_res;
	}

	public void setAct_res(String act_res) {
		this.act_res = act_res;
	}

	public String getTest_result() {
		return test_result;
	}

	public void setTest_result(String test_result) {
		this.test_result = test_result;
	}

	public int getZipcode() {
		return zipcode;
	}

	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}

	public int getMobileno() {
		return mobileno;
	}

	public void setMobileno(int mobileno) {
		this.mobileno = mobileno;
	}
	
	
	
	
	
}
