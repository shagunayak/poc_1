package base_class;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Launch_browser {
	
	
	WebDriver dr;
	
	public WebDriver launch(String url,String browser)
	{
		if(browser=="chrome")
		{
			System.setProperty("webdriver.chrome.driver", "chromedriver_75.exe");
			dr=new  ChromeDriver();
		}
		
		else if(browser=="ie")
		{
			System.setProperty("webdriver.ie.driver", "IDEriverServer.exe");
			dr=new InternetExplorerDriver();
		}
		
		else if(browser=="firefox") 
		{
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			dr=new FirefoxDriver();
		}
		else 
		{
			System.out.println("please select browser");
		}
		
		dr.get(url);
		return dr;
	}

}
